import sys
sys.stdout.reconfigure(encoding="utf-8")

import asyncio
import json
import os
from contextlib import AsyncExitStack
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from openai import AsyncOpenAI
from pydantic import BaseModel

ROOT = Path(__file__).parent
WORKSPACE = ROOT / "workspace"
MEMORY_FILE = ROOT / "memory.md"
MCP_CONFIG = ROOT / "mcp_servers.json"

# ---- BLOCK 1: safety settings ------------------------------------------
MAX_STEPS = 8                  # max model calls per user message
APPROVE_WRITES = "ask"         # "ask" = prompt y/N | "auto" = allow | "deny" = block
NEEDS_APPROVAL = {"write_file"}  # tools that need a human OK

class ModelConfig(BaseModel):
    base_url: str
    api_key: str = "none"
    model: str

MODELS: dict[str, ModelConfig] = {
    "local": ModelConfig(
        base_url="http://localhost:11434/v1",
        api_key="ollama",
        model="qwen3.5:4b",
    ),
    "local-small": ModelConfig(
        base_url="http://localhost:11434/v1",
        api_key="ollama",
        model="qwen3.5:2b",
    ),
    "gpt": ModelConfig(
        base_url="https://api.openai.com/v1",
        api_key=os.getenv("OPENAI_API_KEY", ""),
        model="gpt-5.2",
    ),
    "claude": ModelConfig(
        base_url="https://api.anthropic.com/v1/",
        api_key=os.getenv("ANTHROPIC_API_KEY", ""),
        model="claude-sonnet-5",
    ),
}

model_name = "local"

def load_memory() -> str:
    if MEMORY_FILE.is_file():
        return MEMORY_FILE.read_text(encoding="utf-8")
    return "(nothing saved yet)"

def save_memory(fact: str) -> str:
    with MEMORY_FILE.open("a", encoding="utf-8") as f:
        f.write(f"- {fact}\n")
    return f"saved: {fact}"

def list_files() -> str:
    return "\n".join(p.name for p in WORKSPACE.iterdir()) or "(empty)"

class ToolError(Exception):
    """An expected tool problem. The message goes back to the model."""

def safe_path(filename: str) -> Path:
    """Resolve a filename and refuse anything outside the workspace.

    resolve() collapses '..' and follows symlinks; an absolute path like
    /etc/passwd also lands outside and is refused.
    """
    path = (WORKSPACE / filename).resolve()
    if not path.is_relative_to(WORKSPACE.resolve()):
        raise ToolError(f"'{filename}' is outside the workspace. Access denied.")
    return path

def read_file(filename: str) -> str:
    path = safe_path(filename)
    if not path.is_file():
        raise ToolError(f"no file named '{filename}'")
    return path.read_text(encoding="utf-8")

def write_file(filename: str, content: str) -> str:
    path = safe_path(filename)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return f"wrote {filename} ({len(content)} chars)"

LOCAL_TOOLS = {
    "list_files": list_files,
    "read_file": read_file,
    "write_file": write_file,
    "save_memory": save_memory,
}

TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "List the files in the user's workspace folder.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read one file from the user's workspace folder.",
            "parameters": {
                "type": "object",
                "properties": {"filename": {"type": "string"}},
                "required": ["filename"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write a file in the user's workspace folder.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {"type": "string"},
                    "content": {"type": "string"},
                },
                "required": ["filename", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "save_memory",
            "description": (
                "Save one short fact about the user to long-term memory. "
                "Use whenever you learn something lasting: their name, "
                "preferences, projects, recurring tasks."
            ),
            "parameters": {
                "type": "object",
                "properties": {"fact": {"type": "string"}},
                "required": ["fact"],
            },
        },
    },
]

SYSTEM_PROMPT = """You are a helpful personal assistant running inside a \
custom harness. Be concise.

The user's workspace folder holds their personal files: notes, todo lists, \
ideas. You have tools to list, read, and write those files. Never claim you \
lack access to the user's files or tasks - use your tools to look.

Here is what you remember about the user from previous sessions:
{memory}

When you learn a new lasting fact about the user, save it with save_memory."""

messages = [{"role": "system", "content": SYSTEM_PROMPT.format(memory=load_memory())}]

mcp_sessions: dict[str, ClientSession] = {}

async def connect_mcp(stack: AsyncExitStack):
    config = json.loads(MCP_CONFIG.read_text(encoding="utf-8"))
    for name, spec in config["mcpServers"].items():
        params = StdioServerParameters(command=spec["command"], args=spec["args"])
        try:
            read, write = await stack.enter_async_context(stdio_client(params))
            session = await stack.enter_async_context(ClientSession(read, write))
            await session.initialize()
        except Exception as e:
            print(f"  [mcp] '{name}' failed to start: {e}")
            continue
        tools = (await session.list_tools()).tools
        for tool in tools:
            mcp_sessions[tool.name] = session
            TOOL_SCHEMAS.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description,
                        "parameters": tool.input_schema,
                    },
                }
            )
        print(f"  [mcp] connected '{name}': {[t.name for t in tools]}")

async def approve(name: str, args: dict) -> bool:
    """Ask a human before a risky tool runs. input() runs in a thread so the
    event loop (and the MCP connections) keep working while we wait."""
    if APPROVE_WRITES == "auto":
        return True
    if APPROVE_WRITES == "deny":
        return False
    preview = str(args.get("content", ""))[:200]
    print(f"\n  [approval needed] {name} -> {args.get('filename')}")
    print(f"  preview: {preview!r}")
    answer = await asyncio.to_thread(input, "  allow? [y/N]: ")
    return answer.strip().lower() in ("y", "yes")

async def call_tool(name: str, args: dict) -> str:
    """Run one tool. Never raises: every failure becomes text for the model."""
    try:
        if name in NEEDS_APPROVAL and not await approve(name, args):
            return ("error: the user denied this action. Do not retry it; "
                    "tell the user it was not done.")
        if name in LOCAL_TOOLS:
            return LOCAL_TOOLS[name](**args)
        if name in mcp_sessions:
            result = await mcp_sessions[name].call_tool(name, args)
            text = "\n".join(c.text for c in result.content if hasattr(c, "text"))
            return f"error: {text}" if getattr(result, "isError", False) else text
        known = ", ".join(s["function"]["name"] for s in TOOL_SCHEMAS)
        return f"error: unknown tool '{name}'. Available tools: {known}"
    except ToolError as e:
        return f"error: {e}"
    except TypeError as e:
        return f"error: wrong arguments for '{name}': {e}"
    except Exception as e:
        return f"error: '{name}' failed: {type(e).__name__}: {e}"

async def run_agent(user_message: str) -> str:
    cfg = MODELS[model_name]
    client = AsyncOpenAI(base_url=cfg.base_url, api_key=cfg.api_key)
    messages.append({"role": "user", "content": user_message})
    for step in range(1, MAX_STEPS + 1):
        response = await client.chat.completions.create(
            model=cfg.model, messages=messages, tools=TOOL_SCHEMAS
        )
        message = response.choices[0].message
        if not message.tool_calls:
            messages.append({"role": "assistant", "content": message.content})
            return message.content or ""
        messages.append(message)
        for call in message.tool_calls:
            name = call.function.name
            try:
                args = json.loads(call.function.arguments or "{}")
                if not isinstance(args, dict):
                    raise ValueError("arguments must be a JSON object")
            except ValueError as e:  # JSONDecodeError is a ValueError
                print(f"  [tool] {name} BAD ARGUMENTS")
                result = (f"error: could not parse arguments for '{name}': {e}. "
                          "Call the tool again with valid JSON arguments.")
            else:
                print(f"  [tool] {name}({args})")
                result = await call_tool(name, args)
            # every tool_call MUST get a tool message back, even on errors,
            # or the next API request is rejected
            messages.append(
                {"role": "tool", "tool_call_id": call.id, "content": result}
            )
    stop = (f"Stopped after {MAX_STEPS} steps without a final answer. "
            "Ask me to continue or rephrase.")
    messages.append({"role": "assistant", "content": stop})
    return stop

def handle_command(line: str) -> bool:
    global model_name
    if not line.startswith("/"):
        return False
    cmd, _, arg = line.partition(" ")
    if cmd == "/models":
        for name, cfg in MODELS.items():
            marker = "*" if name == model_name else " "
            print(f" {marker} {name:<12} {cfg.model}  ({cfg.base_url})")
    elif cmd == "/model":
        if arg in MODELS:
            model_name = arg
            print(f"  switched to {arg} ({MODELS[arg].model})")
        else:
            print(f"  unknown model '{arg}' - try /models")
    elif cmd == "/tools":
        for schema in TOOL_SCHEMAS:
            fn = schema["function"]
            origin = "local" if fn["name"] in LOCAL_TOOLS else "mcp"
            print(f"  [{origin}] {fn['name']}: {fn['description'][:60]}")
    elif cmd == "/memory":
        print(load_memory())
    elif cmd == "/quit":
        raise SystemExit
    else:
        print("  commands: /models /model <name> /tools /memory /quit")
    return True

async def main():
    async with AsyncExitStack() as stack:
        print("starting harness...")
        await connect_mcp(stack)
        print(
            f"\nharness ready - model: {model_name} "
            f"({MODELS[model_name].model}), "
            f"{len(TOOL_SCHEMAS)} tools, memory loaded"
        )
        print("type /models, /model <name>, /tools, /memory, or just talk\n")
        try:
            while True:
                line = (await asyncio.to_thread(input, "you: ")).strip()
                if not line or handle_command(line):
                    continue
                print("\nassistant:", await run_agent(line), "\n")
        except (EOFError, KeyboardInterrupt, SystemExit):
            print("\nbye!")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nHarness stopped.")
