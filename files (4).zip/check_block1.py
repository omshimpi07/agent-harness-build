"""Block 1 checks. No model and no Ollama needed.

Run from your project folder AFTER replacing harness.py with the Block 1
version:   python check_block1.py
"""
import asyncio
from types import SimpleNamespace as NS

import harness

results = []


def check(name, ok):
    results.append(ok)
    print(("PASS  " if ok else "FAIL  ") + name)


def run(name, args):
    return asyncio.run(harness.call_tool(name, args))


def reset_history():
    del harness.messages[1:]  # keep only the system prompt


# ---- 1. path safety ------------------------------------------------------
harness.APPROVE_WRITES = "auto"
check("traversal '../secret.txt' blocked",
      "outside the workspace" in run("read_file", {"filename": "../secret.txt"}))
secret_abs = str((harness.ROOT / "secret.txt").resolve())
check("absolute path blocked",
      "outside the workspace" in run("read_file", {"filename": secret_abs}))
check("traversal on write blocked",
      "outside the workspace" in run("write_file", {"filename": "../pwned.txt", "content": "x"}))
check("pwned.txt was NOT created", not (harness.ROOT / "pwned.txt").exists())
check("normal read still works",
      not run("read_file", {"filename": "notes.txt"}).startswith("error"))
check("missing file gives clean error",
      run("read_file", {"filename": "nope.txt"}).startswith("error"))

# ---- 2. write approval ---------------------------------------------------
harness.APPROVE_WRITES = "deny"
out = run("write_file", {"filename": "_t.txt", "content": "x"})
check("write denied when approval = deny", "denied" in out)
check("denied write created no file", not (harness.WORKSPACE / "_t.txt").exists())
harness.APPROVE_WRITES = "auto"
check("write works when approval = auto",
      run("write_file", {"filename": "_t.txt", "content": "x"}).startswith("wrote"))
(harness.WORKSPACE / "_t.txt").unlink(missing_ok=True)

# ---- 3. tool errors never crash -----------------------------------------
check("wrong arguments handled",
      run("read_file", {"wrong": 1}).startswith("error: wrong arguments"))
check("unknown tool handled", run("nope", {}).startswith("error: unknown tool"))


# ---- 4. loop limits, using a fake model client -----------------------------
def tool_call_response(name, arguments, call_id="c1"):
    call = NS(id=call_id, function=NS(name=name, arguments=arguments))
    return NS(choices=[NS(message=NS(tool_calls=[call], content=None))])


def text_response(text):
    return NS(choices=[NS(message=NS(tool_calls=None, content=text))])


class FakeClient:
    def __init__(self, script):
        self.script, self.calls = script, 0
        self.chat = self
        self.completions = self

    async def create(self, **kwargs):
        self.calls += 1
        return self.script(self.calls)


def use_fake(script):
    fake = FakeClient(script)
    harness.AsyncOpenAI = lambda **kw: fake
    return fake


# model that never stops calling tools -> must stop at MAX_STEPS
reset_history()
fake = use_fake(lambda n: tool_call_response("list_files", "{}", f"c{n}"))
answer = asyncio.run(harness.run_agent("loop forever"))
check(f"infinite tool loop stops at MAX_STEPS ({harness.MAX_STEPS})",
      fake.calls == harness.MAX_STEPS and "Stopped after" in answer)

# model that sends broken JSON once, then answers
reset_history()
fake = use_fake(lambda n: tool_call_response("read_file", "{not json") if n == 1
                else text_response("recovered"))
answer = asyncio.run(harness.run_agent("bad json test"))
tool_msgs = [m for m in harness.messages if isinstance(m, dict) and m.get("role") == "tool"]
check("broken JSON arguments do not crash; error goes back to the model",
      answer == "recovered" and tool_msgs and "could not parse" in tool_msgs[0]["content"])

print(f"\n{sum(results)}/{len(results)} checks passed")
raise SystemExit(0 if all(results) else 1)
